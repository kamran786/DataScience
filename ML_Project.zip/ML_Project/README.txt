We have used smaller set of data since the number of records in the original dataset was more.



We have used 10k datapoints from the original dataset run the code on it.



Below are the files which are used in the Python Notebook.



Property File: "properties_2016_10k.csv"



Logerror-file: "train_2016_v2.csv"



Submission File: "sample_submission.csv"